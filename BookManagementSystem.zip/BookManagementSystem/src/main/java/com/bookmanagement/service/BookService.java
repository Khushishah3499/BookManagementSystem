package com.bookmanagement.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.bookmanagement.dto.BookDTO;
import com.bookmanagement.exception.BookNotFoundException;
import com.bookmanagement.model.BookModel;
import com.bookmanagement.repository.BookRepository;

@Service
public class BookService implements IBookService {

    private final BookRepository bookRepository;

    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public List<BookDTO> getAllBooks(int page, int size, String sortField, String sortDirection) {
        Sort sort = sortDirection.equalsIgnoreCase("desc") ? Sort.by(sortField).descending() : Sort.by(sortField).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<BookModel> bookPage = bookRepository.findAll(pageable);

        return bookPage.getContent().stream()
            .map(book -> new BookDTO(
                book.getId(),
                book.getTitle(),
                book.getAuthor(),
                book.getGenre(),
                book.getPublishDate().toString()
            ))
            .collect(Collectors.toList());
    }

    @Override
    public BookDTO getBookById(Long id) {
        Optional<BookModel> optionalBook = bookRepository.findById(id);
        if (optionalBook.isEmpty()) {
            throw new BookNotFoundException("Book with ID " + id + " not found.");
        }
        BookModel book = optionalBook.get();
        return new BookDTO(
            book.getId(),
            book.getTitle(),
            book.getAuthor(),
            book.getGenre(),
            book.getPublishDate().toString()
        );
    }

    @Override
    public void saveBook(BookDTO bookDTO) {
        BookModel book = new BookModel(
            bookDTO.getTitle(),
            bookDTO.getAuthor(),
            bookDTO.getGenre(),
            LocalDate.parse(bookDTO.getPublishDate())
        );
        bookRepository.save(book);
    }

    @Override
    public void updateBook(Long id, BookDTO bookDTO) {
        Optional<BookModel> optionalBook = bookRepository.findById(id);
        if (optionalBook.isEmpty()) {
            throw new BookNotFoundException("Book with ID " + id + " not found.");
        }
        BookModel book = optionalBook.get();
        book.setTitle(bookDTO.getTitle());
        book.setAuthor(bookDTO.getAuthor());
        book.setGenre(bookDTO.getGenre());
        book.setPublishDate(LocalDate.parse(bookDTO.getPublishDate()));
        bookRepository.save(book);
    }

    @Override
    public void deleteBook(Long id) {
        if (!bookRepository.existsById(id)) {
            throw new BookNotFoundException("Book with ID " + id + " not found.");
        }
        bookRepository.deleteById(id);
    }
}
