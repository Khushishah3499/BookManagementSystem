package com.bookmanagement.service;

import java.util.List;
import com.bookmanagement.dto.BookDTO;

public interface IBookService {
    List<BookDTO> getAllBooks(int page, int size, String sortField, String sortDirection);
    BookDTO getBookById(Long id);
    void saveBook(BookDTO bookDTO);
    void updateBook(Long id, BookDTO bookDTO);
    void deleteBook(Long id);
}