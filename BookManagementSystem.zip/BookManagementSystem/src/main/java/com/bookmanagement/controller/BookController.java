package com.bookmanagement.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bookmanagement.dto.BookDTO;
import com.bookmanagement.service.BookService;

@Controller
@RequestMapping("/books")
public class BookController {

	private final BookService bookService;

	public BookController(BookService bookService) {
		this.bookService = bookService;
	}

	@GetMapping
	public String listBooks(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "5") int size,
			@RequestParam(defaultValue = "title") String sortField,
			@RequestParam(defaultValue = "asc") String sortDirection, Model model) {

		List<BookDTO> books = bookService.getAllBooks(page, size, sortField, sortDirection);
		model.addAttribute("books", books);
		model.addAttribute("currentPage", page);
		model.addAttribute("size", size);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);

		return "books";
	}

	@GetMapping("/add")
	public String showAddForm(Model model) {
		model.addAttribute("book", new BookDTO());
		return "addBook";
	}

	@GetMapping("/edit/{id}")
	public String showEditForm(@PathVariable Long id, Model model) {
		model.addAttribute("book", bookService.getBookById(id));
		return "addBook";
	}

	@PostMapping("/save")
	public String saveOrUpdateBook(@ModelAttribute("book") BookDTO bookDTO, Model model) {
		LocalDate today = LocalDate.now();

		if (bookDTO.getPublishDate() == null || LocalDate.parse(bookDTO.getPublishDate()).isAfter(today)) {
			model.addAttribute("dateError", "Publish date cannot be in the future");
			model.addAttribute("book", bookDTO);
			return "error";
		}
		if (bookDTO.getId() == null) {
			bookService.saveBook(bookDTO); // Add new book
		} else {
			bookService.updateBook(bookDTO.getId(), bookDTO); // Update existing book
		}

		return "redirect:/books";
	}

	@GetMapping("/delete/{id}")
	public String deleteBook(@PathVariable Long id) {
		bookService.deleteBook(id);
		return "redirect:/books";
	}
}
